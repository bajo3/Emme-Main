// app/services/index.js
import React from 'react'
import { Text, Button } from 'react-native'
import { useRouter } from 'expo-router'
import Screen from '../../components/ui/Screen'
import SectionTitle from '../../components/ui/SectionTitle'
import Spacer from '../../components/ui/Spacer'

export default function ServicesScreen() {
  const router = useRouter()

  return (
    <Screen>
      <SectionTitle
        right={<Button title="Nuevo" onPress={() => router.push('/services/new')} />}
      >
        Servicios
      </SectionTitle>
      <Spacer />
      <Text>Acá vamos a mostrar y editar todos los servicios (uñas, depilación, etc.).</Text>
    </Screen>
  )
}
