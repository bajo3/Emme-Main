// app/clients/index.js
import React from 'react'
import { Text, Button } from 'react-native'
import { useRouter } from 'expo-router'
import Screen from '../../components/ui/Screen'
import SectionTitle from '../../components/ui/SectionTitle'
import Spacer from '../../components/ui/Spacer'

export default function ClientsScreen() {
  const router = useRouter()

  return (
    <Screen>
      <SectionTitle
        right={<Button title="Nuevo" onPress={() => router.push('/clients/new')} />}
      >
        Clientes
      </SectionTitle>
      <Spacer />
      <Text>Después listamos clientes desde Supabase.</Text>
    </Screen>
  )
}
