// app/clients/_layout.js
import { Stack } from 'expo-router'

export default function ClientsLayout() {
  return <Stack screenOptions={{ headerShown: false }} />
}