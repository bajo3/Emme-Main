// app/appointments/_layout.js
import { Stack } from 'expo-router'

export default function AppointmentsLayout() {
  return <Stack screenOptions={{ headerShown: false }} />
}